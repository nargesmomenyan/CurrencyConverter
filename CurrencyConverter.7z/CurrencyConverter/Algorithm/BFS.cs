﻿using CurrencyConverter.DTO;
using System;
using System.Collections.Generic;

namespace CurrencyConverter.Algorithm
{
    public class BFS
    {
        public List<string> ShortestPath(string source, string destination, Graph graph)
        {
            Dictionary<string, string> previous = new Dictionary<string, string>();
            List<string> path = new List<string>();

            if (!graph.AdjacencyList.ContainsKey(source) || !graph.AdjacencyList.ContainsKey(destination))
                return path;

            Queue<string> queue = new Queue<string>();
            queue.Enqueue(source);

            bool found = false;
            while (queue.Count > 0)
            {
                var vertex = queue.Dequeue();
                if (found)
                    break;

                foreach (var neighbor in graph.AdjacencyList[vertex])
                {
                    if (previous.ContainsKey(neighbor))
                        continue;
                    previous[neighbor] = vertex;
                    if (neighbor == destination)
                    {
                        found = true;
                        break;
                    }
                    queue.Enqueue(neighbor);
                }
            }
            if (!previous.ContainsKey(destination))
                return path;

            var current = destination;
            while (current != source)
            {
                path.Add(current);
                current = previous[current];
            }
            path.Add(source);
            path.Reverse();
            return path;
        }
    }
}
