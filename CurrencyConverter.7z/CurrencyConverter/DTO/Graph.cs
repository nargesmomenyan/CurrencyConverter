﻿using System;
using System.Collections.Generic;

namespace CurrencyConverter.DTO
{
    public class Graph
    {
        public Dictionary<string, List<string>> AdjacencyList { get; } = new Dictionary<string, List<string>>();

        public Graph()
        {

        }
        public Graph(IEnumerable<string> vertices, IEnumerable<Tuple<string, string>> edges)
        {
            foreach (var vertex in vertices)
            {
                this.AddVertex(vertex);
            }

            foreach (var edge in edges)
            {
                this.AddEdge(edge);
            }
        }
        public void AddVertex(string vertex)
        {
            if (!this.AdjacencyList.ContainsKey(vertex))
                this.AdjacencyList[vertex] = new List<string>();
        }

        public void AddEdge(Tuple<string, string> edge)
        {
            if(this.AdjacencyList.ContainsKey(edge.Item1) && this.AdjacencyList.ContainsKey(edge.Item2))
            {
                this.AdjacencyList[edge.Item1].Add(edge.Item2);
                this.AdjacencyList[edge.Item2].Add(edge.Item1);
            }
        }
    }
}
