﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.DTO
{
    public class ConversionItem
    {
        public string SourceCurrency { get; set; }
        public string DestinationCurrency { get; set; }
        public double Rate { get; set; }
    }
}
