﻿using CurrencyConverter.DTO;
using CurrencyConverter.Facade;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace CurrencyConverter
{
    class CurrencyConverter : ICurrencyConverter
    {
        Graph currencyGraph;
        List<ConversionItem> conversionList;

        public CurrencyConverter()
        {
            this.currencyGraph = new Graph();
            this.conversionList = new List<ConversionItem>();
        }
        public void ClearConfiguration()
        {
            this.currencyGraph = new Graph();
            this.conversionList = new List<ConversionItem>();
        }

        public double Convert(string fromCurrency, string toCurrency, double amount)
        {
            double rate = default;
            var bfs = new Algorithm.BFS();
            var path = bfs.ShortestPath(fromCurrency, toCurrency, this.currencyGraph);
            if (path.Count == 0)
                return rate;
            if (path.Count == 1)
                return amount;

            rate = 1;
            for (int i = 0; i < path.Count - 1; i++)
            {
                var conversionItem = this.conversionList
                    .FirstOrDefault(x => x.SourceCurrency == path[i] && x.DestinationCurrency == path[i + 1]);

                if (conversionItem != null)
                    rate *= conversionItem.Rate;
                else
                {
                    conversionItem = this.conversionList
                    .FirstOrDefault(x => x.SourceCurrency == path[i + 1] && x.DestinationCurrency == path[i]);
                    rate *= (1 / conversionItem.Rate);
                }
            }
            return rate * amount;
        }

        public void UpdateConfiguration(IEnumerable<Tuple<string, string, double>> conversionRates)
        {
            foreach (var conversionItem in conversionRates)
            {
                var foundItem = conversionList.FirstOrDefault(x => x.SourceCurrency == conversionItem.Item1 && x.DestinationCurrency == conversionItem.Item2);
                if (foundItem != null)
                    foundItem.Rate = conversionItem.Item3;

                if (foundItem == null)
                {
                    foundItem = conversionList.FirstOrDefault(x => x.SourceCurrency == conversionItem.Item2 && x.DestinationCurrency == conversionItem.Item1);
                    if (foundItem != null)
                        foundItem.Rate = 1 / conversionItem.Item3;
                }
                if (foundItem == null)
                {
                    this.conversionList.Add(
                        new ConversionItem
                        {
                            SourceCurrency = conversionItem.Item1,
                            DestinationCurrency = conversionItem.Item2,
                            Rate = conversionItem.Item3
                        });
                    this.currencyGraph.AddVertex(conversionItem.Item1);
                    this.currencyGraph.AddVertex(conversionItem.Item2);
                    this.currencyGraph.AddEdge(Tuple.Create(conversionItem.Item1, conversionItem.Item2));
                }
            }
        }
    }
}
