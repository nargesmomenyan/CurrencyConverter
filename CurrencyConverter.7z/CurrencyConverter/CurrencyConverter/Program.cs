﻿using Autofac;
using CurrencyConverter.DTO;
using CurrencyConverter.Facade;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace CurrencyConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            Autofac.ContainerBuilder builder = new Autofac.ContainerBuilder();
            builder.RegisterType<CurrencyConverter>().As<ICurrencyConverter>().SingleInstance();

            var container = builder.Build();
            var converter = container.Resolve<ICurrencyConverter>();

            converter.UpdateConfiguration(new[]
            {
                Tuple.Create("USD","CAD", (double)1.34),
                Tuple.Create("CAD","GBP", (double).58),
                Tuple.Create("USD","EUR",(double) .86),
                Tuple.Create( "Rial","Toman",(double) .1)
            });

            Stopwatch watch = new Stopwatch();
            watch.Start();

            var a1 = Task.Run(() => converter.Convert("USD", "CAD", 1));
            var a2 = Task.Run(() => converter.Convert("USD", "CAD", 1));
            var a3 = Task.Run(() => converter.Convert("CAD", "USD", 1));
            var a4 = Task.Run(() => converter.Convert("CAD", "GBP", 1));
            var a5 = Task.Run(() => converter.Convert("GBP", "CAD", 1));
            var a6 = Task.Run(() => converter.Convert("CAD", "EUR", 1));
            Console.WriteLine("USD -> CAD: " + a1.Result);
            Console.WriteLine("USD -> CAD: " + a2.Result);
            Console.WriteLine("CAD -> USD: " + a3.Result);
            Console.WriteLine("CAD -> GBP: " + a4.Result);
            Console.WriteLine("GBP -> CAD: " + a5.Result);
            Console.WriteLine("CAD -> EUR: " + a6.Result);
            watch.Stop();
            Console.WriteLine("ElapsedMilliseconds: "+ watch.ElapsedMilliseconds);


            Console.ReadLine();
        }
    }
}
